package com.example.ticketmaker.Class

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "product_table")
data class Product(
    @ColumnInfo(name="code")
    var code: String?,

    @ColumnInfo(name="price")
    var price: Double,

    @ColumnInfo(name="dscr")
    var dscr: String?
){

    //does it matter if these are private or not?
    @PrimaryKey(autoGenerate = true)
    var id: Int = 0

}