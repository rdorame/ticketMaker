package com.example.ticketmaker.Class

class TicketProductItem (var dscr : String, var  ns : String, var clave : String, var cant : Int, var p_unit : Float, var subtotal : Float){
}