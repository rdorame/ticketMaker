package com.example.ticketmaker.Room

class IProductDataSource {
}